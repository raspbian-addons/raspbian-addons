"""Main Lutris package"""

__version__ = "0.5.8.3"

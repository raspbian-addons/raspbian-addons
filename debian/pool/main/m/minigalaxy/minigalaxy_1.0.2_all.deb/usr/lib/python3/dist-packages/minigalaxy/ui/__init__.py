""" MiniGalaxy gui windows """
from minigalaxy.ui.window import Window
from minigalaxy.ui.preferences import Preferences
from minigalaxy.ui.gametile import GameTile

LOCALEDIR = "/usr/share/locale"
PKGVERSION = "2.0.7"
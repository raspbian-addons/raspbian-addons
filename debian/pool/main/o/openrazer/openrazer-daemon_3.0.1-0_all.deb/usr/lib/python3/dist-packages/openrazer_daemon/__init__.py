"""
Razer Daemon module
"""
